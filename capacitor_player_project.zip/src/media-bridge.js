import { MediaSession } from '@capgo/capacitor-media-session';

const isNative = !!(window.Capacitor &&
  typeof window.Capacitor.isNativePlatform === 'function' &&
  window.Capacitor.isNativePlatform());

if (isNative) {
  const audio = document.getElementById('audio-player');
  const callPlayer = (action, value) => {
    try {
      if (typeof window.WebToApkOnMediaAction === 'function') {
        window.WebToApkOnMediaAction(action, value);
      }
    } catch (e) {
      console.warn('Media action failed:', action, e);
    }
  };
  const safe = promise => Promise.resolve(promise).catch(e => console.warn('MediaSession:', e));

  // Native Android notification / lock-screen controls.
  const handlers = {
    play: () => callPlayer('play'),
    pause: () => callPlayer('pause'),
    stop: () => callPlayer('stop'),
    previoustrack: () => callPlayer('previoustrack'),
    nexttrack: () => callPlayer('nexttrack'),
    seekto: details => {
      if (details && Number.isFinite(details.seekTime)) callPlayer('seekto', details.seekTime);
    },
    seekforward: details => callPlayer('seekforward'),
    seekbackward: details => callPlayer('seekbackward')
  };

  for (const [action, handler] of Object.entries(handlers)) {
    safe(MediaSession.setActionHandler({ action }, handler));
  }

  window.addEventListener('player:metadata', event => {
    const m = event.detail || {};
    const artwork = m.artwork ? [{
      src: m.artwork,
      sizes: '512x512',
      type: String(m.artwork).startsWith('data:image/png') ? 'image/png' : 'image/jpeg'
    }] : [];
    safe(MediaSession.setMetadata({
      title: m.title || document.title,
      artist: m.artist || '',
      album: m.album || '',
      artwork
    }));
  });

  let lastPositionSent = 0;
  const publishState = () => {
    if (!audio) return;
    const duration = Number(audio.duration);
    const position = Number(audio.currentTime);
    safe(MediaSession.setPlaybackState({
      playbackState: audio.paused ? 'paused' : 'playing'
    }));
    if (Number.isFinite(duration) && duration > 0 && Number.isFinite(position)) {
      safe(MediaSession.setPositionState({
        duration,
        position: Math.max(0, Math.min(position, duration)),
        playbackRate: audio.playbackRate || 1
      }));
    }
  };

  window.addEventListener('player:state', event => {
    const d = event.detail || {};
    safe(MediaSession.setPlaybackState({
      playbackState: d.playing ? 'playing' : 'paused'
    }));
    if (Number.isFinite(d.duration) && d.duration > 0 && Number.isFinite(d.position)) {
      safe(MediaSession.setPositionState({
        duration: d.duration,
        position: Math.max(0, Math.min(d.position, d.duration)),
        playbackRate: d.playbackRate || 1
      }));
    }
  });

  if (audio) {
    ['play', 'playing', 'pause', 'ended', 'loadedmetadata', 'durationchange', 'seeked', 'ratechange']
      .forEach(name => audio.addEventListener(name, publishState));
    audio.addEventListener('timeupdate', () => {
      const now = Date.now();
      if (now - lastPositionSent < 900) return;
      lastPositionSent = now;
      publishState();
    });
  }
  console.info('Native Android MediaSession bridge enabled');
}
