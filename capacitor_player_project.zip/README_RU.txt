# Сборка APK из HTML-плеера на телефоне

В архиве сохранён исходный HTML-плеер и добавлен мост Capacitor Media Session.

## Что нужно
- Аккаунт GitHub.
- Браузер Samsung.
- Включённые GitHub Actions.

## Сборка
1. Создайте на GitHub новый репозиторий.
2. Загрузите в корень репозитория `capacitor-player-project.zip` (этот архив).
3. Создайте файл `.github/workflows/android.yml` и вставьте содержимое файла `android-build-workflow.yml`.
4. Откройте вкладку Actions, выберите `Build Android APK`, нажмите `Run workflow`.
5. После завершения откройте запуск workflow, найдите Artifacts и скачайте `Spotify-Local-Player-APK`.
6. Распакуйте артефакт и установите `app-debug.apk` на Samsung.

Это тестовая debug-сборка, не релиз для Google Play. Android может запросить разрешение на установку приложений из браузера/файлового менеджера.
